from __future__ import annotations

from typing import Optional, Iterable, Tuple
import torch
from pathlib import Path
import onnxruntime as ort
import numpy as np

DEFAULT_WORLD_UP = np.array([0.0, 0.0, 1.0], dtype=np.float32)
DEPTH_MIN_M = 0.5
DEPTH_MAX_M = 20.0
MAX_YAW_RATE = 3.141
SIM_DT = 1 / 50
CAMERA_FOV_DEG = 90.0
CAMERA_OFFSET_M = 0.13
CAMERA_UP_OFFSET_M = 0.05
m_STATE_DIM = 141

class Gains:
    K: float = 0.4


class _ABTracker:

    def __init__(self, alpha=0.45, beta=0.10, dt=SIM_DT):
        self.alpha = float(alpha)
        self.beta = float(beta)
        self.dt = float(dt)
        self.pos = None
        self.vel = np.zeros(3, dtype=np.float32)
        self.initialized = False

    def reset(self):
        self.pos = None
        self.vel = np.zeros(3, dtype=np.float32)
        self.initialized = False

    def update(self, m):
        m = np.asarray(m, dtype=np.float32).reshape(3)
        if not self.initialized:
            self.pos = m.copy()
            self.vel = np.zeros(3, dtype=np.float32)
            self.initialized = True
            return
        pos_pred = self.pos + self.vel * self.dt
        r = m - pos_pred
        self.pos = pos_pred + self.alpha * r
        self.vel = self.vel + (self.beta / self.dt) * r
        vn = float(np.linalg.norm(self.vel))
        if vn > 3.0:
            self.vel = self.vel * (3.0 / vn)


def _prep_depth(depth_map: np.ndarray) -> np.ndarray:
    depth = np.asarray(depth_map, dtype=np.float32)
    if depth.ndim == 3 and depth.shape[-1] == 1:
        depth = depth[..., 0]
    elif depth.ndim != 2:
        raise ValueError(f"expected depth map with shape (H,W) or (H,W,1), got {depth.shape}")

    if depth.shape[0] < 2 or depth.shape[1] < 2:
        raise ValueError(f"depth map is too small: {depth.shape}")

    return np.clip(depth, 0.0, 1.0)


def _norm_depth_m(depth: np.ndarray) -> np.ndarray:
    return DEPTH_MIN_M + depth * (DEPTH_MAX_M - DEPTH_MIN_M)

def _cam_vec_world(
    camera_vector: np.ndarray,
    camera_forward: np.ndarray,
    camera_right: np.ndarray,
    camera_up: np.ndarray,
) -> np.ndarray:
    world = (
        camera_right * float(camera_vector[0])
        + camera_up * float(camera_vector[1])
        + camera_forward * float(camera_vector[2])
    ).astype(np.float32)
    return _norm_vec(world)

def _cam_basis(
    camera_target: np.ndarray,
    *,
    camera_position: np.ndarray,
    camera_target_is_point: bool,
    camera_up: np.ndarray | None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    camera_position = np.asarray(camera_position, dtype=np.float32).reshape(-1)
    if camera_position.shape != (3,):
        raise ValueError(f"expected camera_position shape (3,), got {camera_position.shape}")

    target = np.asarray(camera_target, dtype=np.float32).reshape(-1)
    if target.shape != (3,):
        raise ValueError(f"expected camera_target shape (3,), got {target.shape}")

    if camera_target_is_point:
        target = target - camera_position

    forward = _norm_vec(target)
    up_guess = DEFAULT_WORLD_UP if camera_up is None else _norm_vec(camera_up)

    right = np.cross(forward, up_guess).astype(np.float32)
    if float(np.linalg.norm(right)) <= 1e-8:
        fallback_up = np.array([0.0, 1.0, 0.0], dtype=np.float32)
        right = np.cross(forward, fallback_up).astype(np.float32)

    right = _norm_vec(right)
    up = _norm_vec(np.cross(right, forward))
    return forward, right, up

def _parse_fov(fov_deg: float | Iterable[float]) -> tuple[float, float]:
    if np.isscalar(fov_deg):
        fov_x = float(fov_deg)
        fov_y = float(fov_deg)
    else:
        values = tuple(float(v) for v in fov_deg)
        if len(values) != 2:
            raise ValueError(f"expected scalar FOV or (horizontal, vertical), got {values}")
        fov_x, fov_y = values

    if not (0.0 < fov_x < 180.0 and 0.0 < fov_y < 180.0):
        raise ValueError(f"invalid FOV values: {(fov_x, fov_y)}")
    return fov_x, fov_y


def _min_pool(depth_m: np.ndarray, out_h: int, out_w: int) -> np.ndarray:
    row_idx = np.linspace(0, depth_m.shape[0], out_h + 1, dtype=np.int32)
    col_idx = np.linspace(0, depth_m.shape[1], out_w + 1, dtype=np.int32)
    temp = np.minimum.reduceat(depth_m, row_idx[:-1], axis=0)
    return np.minimum.reduceat(temp, col_idx[:-1], axis=1).astype(np.float32)

def _work_shape(height: int, width: int, working_resolution: int) -> tuple[int, int]:
    if working_resolution < 3:
        raise ValueError(f"working_resolution must be >= 3, got {working_resolution}")

    scale = min(1.0, float(working_resolution) / float(max(height, width)))
    out_h = max(3, int(round(height * scale)))
    out_w = max(3, int(round(width * scale)))

    if out_h % 2 == 0:
        out_h = max(3, out_h - 1)
    if out_w % 2 == 0:
        out_w = max(3, out_w - 1)

    return min(out_h, height), min(out_w, width)

def _cand_rays(
    height: int,
    width: int,
    fov_x_deg: float,
    fov_y_deg: float,
) -> tuple[np.ndarray, np.ndarray]:
    x = np.linspace(-1.0, 1.0, width, dtype=np.float32)
    y = np.linspace(1.0, -1.0, height, dtype=np.float32)
    x_grid, y_grid = np.meshgrid(x, y)

    tan_half_x = float(np.tan(np.deg2rad(np.float32(fov_x_deg)) * 0.5))
    tan_half_y = float(np.tan(np.deg2rad(np.float32(fov_y_deg)) * 0.5))

    ray_points = np.stack(
        [
            x_grid * tan_half_x,
            y_grid * tan_half_y,
            np.ones_like(x_grid, dtype=np.float32),
        ],
        axis=-1,
    ).astype(np.float32)

    ray_norms = np.linalg.norm(ray_points, axis=-1, keepdims=True)
    ray_dirs = (ray_points / np.maximum(ray_norms, 1e-8)).astype(np.float32)
    return ray_points, ray_dirs


def _cam_vecs_world(
    camera_vectors: np.ndarray,
    camera_forward: np.ndarray,
    camera_right: np.ndarray,
    camera_up: np.ndarray,
) -> np.ndarray:
    vectors = np.asarray(camera_vectors, dtype=np.float32)
    if vectors.ndim != 2 or vectors.shape[1] != 3:
        raise ValueError(f"expected camera_vectors shape (N, 3), got {vectors.shape}")

    world = (
        vectors[:, 0:1] * camera_right[None, :]
        + vectors[:, 1:2] * camera_up[None, :]
        + vectors[:, 2:3] * camera_forward[None, :]
    ).astype(np.float32)
    norms = np.linalg.norm(world, axis=1, keepdims=True)
    return (world / np.maximum(norms, 1e-8)).astype(np.float32)


def _safe_ctx(
    depth_map: np.ndarray,
    camera_position: np.ndarray,
    camera_target: np.ndarray,
    fov_deg: float | Iterable[float],
    *,
    current_direction: np.ndarray | None = None,
    camera_target_is_point: bool = False,
    camera_up: np.ndarray | None = None,
    working_resolution: int = 49,
) -> dict:
    depth = _prep_depth(depth_map)
    depth_m = _norm_depth_m(depth)
    fov_x_deg, fov_y_deg = _parse_fov(fov_deg)
    camera_forward, camera_right, camera_up_vector = _cam_basis(
        camera_target,
        camera_position=np.asarray(camera_position, dtype=np.float32),
        camera_target_is_point=camera_target_is_point,
        camera_up=camera_up,
    )

    pooled_h, pooled_w = _work_shape(depth_m.shape[0], depth_m.shape[1], working_resolution)
    pooled_depth_m = _min_pool(depth_m, pooled_h, pooled_w)
    ray_points_cam, ray_dirs_cam = _cand_rays(pooled_h, pooled_w, fov_x_deg, fov_y_deg)

    surface_points_cam = (ray_points_cam * pooled_depth_m[..., None]).astype(np.float32)
    surface_ranges = np.linalg.norm(surface_points_cam, axis=-1)

    candidate_dirs = ray_dirs_cam.reshape(-1, 3)
    candidate_world_dirs = _cam_vecs_world(
        candidate_dirs,
        camera_forward=camera_forward,
        camera_right=camera_right,
        camera_up=camera_up_vector,
    )

    if current_direction is None:
        preferred_direction = camera_forward
    else:
        preferred_candidate = np.asarray(current_direction, dtype=np.float32).reshape(-1)
        if preferred_candidate.shape != (3,):
            raise ValueError(f"expected current_direction shape (3,), got {preferred_candidate.shape}")
        if float(np.linalg.norm(preferred_candidate)) <= 1e-8:
            preferred_direction = camera_forward
        else:
            preferred_direction = _norm_vec(preferred_candidate)

    preference_angles = np.arccos(
        np.clip(candidate_world_dirs @ preferred_direction, -1.0, 1.0)
    ).astype(np.float32)

    obstacle_ranges_sq = np.sum(
        surface_points_cam.reshape(-1, 3) ** 2, axis=1, dtype=np.float32
    )
    projections = candidate_dirs @ surface_points_cam.reshape(-1, 3).T

    return {
        "candidate_dirs": candidate_dirs,
        "camera_forward": camera_forward,
        "camera_right": camera_right,
        "camera_up_vector": camera_up_vector,
        "surface_ranges": surface_ranges,
        "obstacle_ranges_sq": obstacle_ranges_sq,
        "projections": projections,
        "preference_angles": preference_angles,
    }


def _pick_ctx(
    ctx: dict,
    *,
    drone_radius_m: float = 0.06,
    safety_margin_m: float = 0.03,
    preferred_clearance_m: float = 3.0,
    max_lookahead_m: float = 8.0,
) -> np.ndarray:
    candidate_dirs = ctx["candidate_dirs"]
    surface_ranges = ctx["surface_ranges"]
    obstacle_ranges_sq = ctx["obstacle_ranges_sq"]
    projections = ctx["projections"]
    preference_angles = ctx["preference_angles"]

    effective_radius = float(drone_radius_m + safety_margin_m)
    relevant_points = surface_ranges.ravel() <= float(max_lookahead_m + effective_radius)

    if np.any(relevant_points):
        rel_idx = np.flatnonzero(relevant_points)
        proj_rel = projections[:, rel_idx]
        orsq_rel = obstacle_ranges_sq[rel_idx]

        lateral_sq = np.clip(orsq_rel[None, :] - proj_rel * proj_rel, 0.0, None)

        collision_mask = (proj_rel > 0.0) & (lateral_sq < (effective_radius * effective_radius))
        collision_distances = np.full_like(proj_rel, np.inf, dtype=np.float32)

        if np.any(collision_mask):
            penetration = np.sqrt(
                np.maximum((effective_radius * effective_radius) - lateral_sq[collision_mask], 0.0)
            ).astype(np.float32)
            collision_distances[collision_mask] = np.maximum(
                proj_rel[collision_mask] - penetration,
                0.0,
            )

        min_collision_distance = np.min(collision_distances, axis=1)
        min_collision_distance[~np.isfinite(min_collision_distance)] = float(max_lookahead_m)
        clearance_distance = np.minimum(min_collision_distance, float(max_lookahead_m)).astype(np.float32)
    else:
        clearance_distance = np.full(candidate_dirs.shape[0], float(max_lookahead_m), dtype=np.float32)

    safe_candidates = np.flatnonzero(clearance_distance >= float(preferred_clearance_m))
    if safe_candidates.size > 0:
        best_order = np.lexsort(
            (
                -clearance_distance[safe_candidates],
                preference_angles[safe_candidates],
            )
        )
        best_idx = int(safe_candidates[best_order[0]])
    else:
        best_order = np.lexsort((preference_angles, -clearance_distance))
        best_idx = int(best_order[0])

    best_camera_direction = candidate_dirs[best_idx]
    return _cam_vec_world(
        best_camera_direction,
        camera_forward=ctx["camera_forward"],
        camera_right=ctx["camera_right"],
        camera_up=ctx["camera_up_vector"],
    )


def _norm_vec(vector: np.ndarray, eps: float = 1e-8) -> np.ndarray:
    arr = np.asarray(vector, dtype=np.float32).reshape(-1)
    if arr.shape != (3,):
        raise ValueError(f"expected a 3D vector, got shape {arr.shape}")

    norm = float(np.linalg.norm(arr))
    if norm <= eps:
        raise ValueError("cannot normalize a near-zero vector")
    return (arr / norm).astype(np.float32)

def rpy_to_rot(roll: float, pitch: float, yaw: float) -> np.ndarray:
    cr, sr = np.cos(roll), np.sin(roll)
    cp, sp = np.cos(pitch), np.sin(pitch)
    cy, sy = np.cos(yaw), np.sin(yaw)

    rotation_x = np.array([
        [1, 0, 0],
        [0, cr, -sr],
        [0, sr, cr],
    ], dtype=np.float32)

    rotation_y = np.array([
        [cp, 0, sp],
        [0, 1, 0],
        [-sp, 0, cp],
    ], dtype=np.float32)

    rotation_z = np.array([
        [cy, -sy, 0],
        [sy, cy, 0],
        [0, 0, 1],
    ], dtype=np.float32)

    return (rotation_z @ rotation_y @ rotation_x).astype(np.float32)

def _cam_geom(
    drone_position: np.ndarray,
    drone_rpy: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    rotation_matrix = rpy_to_rot(drone_rpy[0], drone_rpy[1], drone_rpy[2])
    forward_direction = _norm_vec(rotation_matrix @ np.array([1.0, 0.0, 0.0], dtype=np.float32))
    up_guess = _norm_vec(rotation_matrix @ np.array([0.0, 0.0, 1.0], dtype=np.float32))
    right_direction = np.cross(forward_direction, up_guess).astype(np.float32)

    if float(np.linalg.norm(right_direction)) <= 1e-8:
        right_direction = np.cross(forward_direction, np.array([0.0, 0.0, 1.0], dtype=np.float32)).astype(np.float32)

    right_direction = _norm_vec(right_direction)
    up_direction = _norm_vec(np.cross(right_direction, forward_direction))

    camera_position = (
        np.asarray(drone_position, dtype=np.float32)
        + forward_direction * CAMERA_OFFSET_M
        + up_guess * CAMERA_UP_OFFSET_M
    ).astype(np.float32)
    camera_target = (camera_position + forward_direction * 20.0).astype(np.float32)

    return camera_position, camera_target, right_direction, up_direction, forward_direction


def slerp_dir(a, b, t, eps=1e-12):
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)

    na, nb = np.linalg.norm(a), np.linalg.norm(b)
    if na < eps or nb < eps:
        return b
    a /= na
    b /= nb

    if t <= 0.0: return a
    if t >= 1.0: return b
 
    cross = np.cross(a, b)
    cross_norm = np.linalg.norm(cross)
    dot = np.clip(np.dot(a, b), -1.0, 1.0)
    angle = np.arctan2(cross_norm, dot)  # in [0, π]

    if angle < 1e-8: 
        v = b
    else:
        if np.pi - angle < 1e-8:  
            x = np.array([1.0, 0.0, 0.0])
            if abs(np.dot(a, x)) > 0.9:
                x = np.array([0.0, 1.0, 0.0])
            k = np.cross(a, x)
            k /= np.linalg.norm(k)
        else:
            k = cross / cross_norm

        c, s = np.cos(t * angle), np.sin(t * angle)
        v = a * c + np.cross(k, a) * s + k * (np.dot(k, a)) * (1 - c)

    return v / np.linalg.norm(v)


class DroneFlightController:
    def __init__(
        self,
        *,
        m_model_path: Optional[Path] = None,
    ):
        script_dir = Path(__file__).resolve().parent

        if m_model_path is None:
            m_model_path = script_dir / "model.pt"
        nav_model_path = script_dir / "navigation_model.onnx"
        self._load_model(m_model_path)
        self._ab_tracker = _ABTracker()
        self.reset()
        
        self._load_navigation_model(nav_model_path)
        self.controller = LandingController(gains=Gains())
    
    def _getSecondOrderAction(self, new_action, state, attitude_action=0.0, is_smooth=True, eps=3e-5):
        if not is_smooth:
            self.prev_action = new_action.copy()
            return new_action.reshape(1, 5)

        def _to_vel(action):
            d = np.asarray(action[:3], dtype=np.float64)
            s = float(action[3])
            n = float(np.linalg.norm(d))
            return d * s if (n >= eps and s >= eps) else np.zeros(3)
        buffer = state[12:137].reshape(25, 5)
        v_k   = _to_vel(buffer[-1])
        v_km1 = _to_vel(buffer[-2])
        a_k   = v_k - v_km1   
        v_sp  = _to_vel(new_action)  

        alpha    = 0.3
        beta     = 0.2
        clip_a   = 0.05

        a_next = alpha * a_k + beta * (v_sp - v_k)
        a_next = np.clip(a_next, -clip_a, clip_a)
        v_next = v_k + a_next

        speed_next = float(np.linalg.norm(v_next))
        if speed_next < eps:
            self.prev_action[:3] = 0.0
            self.prev_action[3]  = 0.0
        else:
            self.prev_action[:3] = (v_next / speed_next).astype(np.float32)
            self.prev_action[3]  = float(speed_next)
        self.prev_action[4] = new_action[4]

        return_action = self.prev_action.copy()
        return_action[2] += attitude_action
        dir_norm = float(np.linalg.norm(return_action[:3]))
        if dir_norm < eps:
            return_action[:3] = 0.0
        else:
            return_action[:3] /= dir_norm
        return return_action.reshape(1, 5)


    def act(self, observation):
        state = np.asarray(observation.get("state", None), dtype=np.float32).squeeze()

        if self.start_state is None:
            self.start_state = state.copy()

        drone_position = np.array([state[0], state[1], state[2]], dtype=float)
        drone_rpy = np.array([state[3], state[4], state[5]], dtype=float)
        drone_velocity = np.array([state[6], state[7], state[8]], dtype=float)
        drone_speed = float(np.linalg.norm(drone_velocity))
        drone_altitude = state[-4] * 20.0

        search_area_vector = np.array([state[-3], state[-2], state[-1]], dtype=float)
        dist_raw_3d = float(np.linalg.norm(search_area_vector))
        self._mountain_flight = dist_raw_3d > 45.0

        if (self._mode == "search" and self._goal_return_mode
                and self._last_known_goal_pos is not None):
            self._goal_return_search_steps += 1
            if self._goal_return_search_steps > 400:
                self._goal_return_mode = False
                self._last_known_goal_pos = None
                self.extra_search_vectors = None
                self.search_stage = 0
                self.search_state_0_rot_count = 0
            else:
                goal_vec = self._last_known_goal_pos - drone_position
                if float(np.linalg.norm(goal_vec)) > 0.1:
                    search_area_vector = goal_vec

        search_area_position = self._get_search_area_position(search_area_vector, drone_position)

        dir_similarity = 1.5 if dist_raw_3d > 10.0 else 0.5
        search_area_vector = search_area_position - drone_position
        distance_to_search_area = float(np.linalg.norm(search_area_vector))
        if distance_to_search_area > 10.0:
            search_area_vector[2] += 1.5
        else:
            offset = 0.5 + distance_to_search_area/10.0
            search_area_vector[2] += offset

        depth = np.asarray(observation["depth"], dtype=np.float32)

        is_goal_visible = False
        visible_goal_position = None
        visible_goal_position_cov = None
        visible_goal_velocity = None

        if distance_to_search_area <= DEPTH_MAX_M or self._mode in ("navigation", "landing"):
            goal_visibility_prob, predicted_goal_position, predicted_goal_position_cov, predicted_platform_velocity = self._find_platform(depth, state)
            if self._goal_is_tracked:
                is_goal_visible = bool(goal_visibility_prob >= self._goal_visible_exit_threshold)
            else:
                is_goal_visible = bool(goal_visibility_prob >= self._goal_visible_enter_threshold)

            self._goal_is_tracked = is_goal_visible
            if is_goal_visible:
                visible_goal_position = predicted_goal_position.copy()
                visible_goal_position_cov = predicted_goal_position_cov.copy()
                visible_goal_velocity = predicted_platform_velocity.copy()
                visible_goal_velocity[2] = 0.0

        slerp_steps = 0.06 / max(1.0, drone_speed / 2.5) if drone_speed >= 4.5 else 0.06

        if self._mode == "takeoff":
            yaw_to_search_area = np.arctan2(search_area_vector[1], search_area_vector[0])
            yaw_to_search_area_diff = (yaw_to_search_area - drone_rpy[2] + np.pi) % (2.0 * np.pi) - np.pi
            yaw_command = self._get_yaw_command(yaw_to_search_area / np.pi, drone_rpy)
            z_command = 0.0
            speed_command = 0.35
            min_altitude = 4.5 if self._mountain_flight and self.is_hatt else 1.5
            if not hasattr(self, "start_state"): self.start_state = None
            if self.start_state is None: self.start_state = state.copy()
            spawn_alt = float(self.start_state[2])
            altitude_gain = float(drone_position[2] - spawn_alt)
            if spawn_alt > 15.0:
                ready_alt = altitude_gain >= 1.5
                if altitude_gain < 1.5:
                    z_command = 1.0
            elif spawn_alt >= 3.0:
                ready_alt = altitude_gain >= 0.5
                if altitude_gain < 0.5:
                    z_command = 1.0
            else:
                ready_alt = drone_altitude >= min_altitude
                if drone_altitude < min_altitude:
                    z_command = 1.0
            if ready_alt and is_goal_visible and abs(yaw_to_search_area_diff) < (np.pi / 6):
                self.first_order_cnt = 20
                self._mode = "navigation"
            elif ready_alt and abs(yaw_to_search_area_diff) < (np.pi / 24):
                self.first_order_cnt = 30
                self._mode = "search"

            action = np.array([0.0, 0.0, z_command, speed_command, yaw_command], dtype=np.float32)
        elif self._mode == "search":
            acceleration_rate = 0.07
            brake_rate = 0.05
            drone_speed_normalized = min(drone_speed,6.0) / 3.0

            if self._landing_platform_position is None:
                if distance_to_search_area > 1.0:
                    if self._forward:
                        acceleration_rate = 0.313
                    yaw_command = np.arctan2(search_area_vector[1], search_area_vector[0])
                    speed_command = min(drone_speed_normalized + acceleration_rate, 2.0)
                    if abs(yaw_command - drone_rpy[2]) > 0.1 and abs(yaw_command - drone_rpy[2]) < (np.pi * 2 - 0.2):
                        speed_command = self._last_action[3]
                        speed_command = max(speed_command, 0.2)
                    if abs(yaw_command - drone_rpy[2]) > 0.3 and abs(yaw_command - drone_rpy[2]) < (np.pi * 2 - 0.5):
                        speed_command = self._last_action[3] - brake_rate
                        speed_command = max(speed_command, 0.2)
                        yaw_command = self._get_yaw_command(yaw_command / np.pi, drone_rpy) * np.pi
                    yaw_command = yaw_command / np.pi
                    if distance_to_search_area < 3.0:
                        max_speed_command = speed_command = distance_to_search_area / 3.0
                        if speed_command < self._last_action[3] - brake_rate:
                            speed_command = self._last_action[3] - brake_rate
                else:
                    if distance_to_search_area < 1.0 and self.search_stage > 0:
                        self.search_stage += 1
                        yaw_command = self._rot_left(drone_rpy[2])
                        if self.search_stage >= len(self.extra_search_vectors):
                            self.search_stage = 0

                    if self.search_stage == 0:
                        self.search_state_0_rot_count += 1
                        if self.search_state_0_rot_count >= 400:
                            self.search_state_0_rot_count = 0
                            self.search_stage = 1
                        yaw_command = self._rot_left(drone_rpy[2])
                    speed_command = distance_to_search_area / 3.0

                    if speed_command < self._last_action[3] - brake_rate:
                        speed_command = self._last_action[3] - brake_rate

                    speed_command = max(speed_command, 0.0)

                direction = search_area_vector

                if float(np.linalg.norm(direction)) > 1e-6:
                    direction_norm = direction / np.linalg.norm(direction)
                else:
                    direction_norm = np.array([0.0, 0.0, 0.0], dtype=np.float32)

                action = np.concatenate([direction_norm, [speed_command, yaw_command]], dtype=np.float32)
            else:
                direction = self._last_action[0:3]
                speed_command = self._last_action[3] - brake_rate
                speed_command = max(speed_command, 0.0)
                yaw_command = self._rot_left(drone_rpy[2])

                action = np.concatenate([direction, [speed_command, yaw_command]], dtype=np.float32)

            if is_goal_visible:
                self._mode = "navigation"
                self.first_order_cnt = 20
                self._goal_return_mode = False
                self._goal_return_search_steps = 0
        elif self._mode == "navigation":
            acceleration_rate = 0.08 if self._forward else 0.05
            brake_rate = 0.05
            drone_speed_normalized = min(drone_speed, 6.0) / 3.0
            if visible_goal_position is not None:
                goal_position = visible_goal_position.copy()
                goal_position[2] += 0.5

                direction = goal_position - drone_position
                distance_to_goal = float(np.linalg.norm(direction))
                yaw_command = np.arctan2(direction[1], direction[0])
                max_speed = min(1.02 + (float(np.linalg.norm(direction[:2]))-4.0)/10.0, 2.0)
                if drone_speed_normalized > max_speed:
                    speed_command = min(drone_speed_normalized - brake_rate, 2.0)
                else:
                    speed_command = min(drone_speed_normalized + acceleration_rate, max_speed)
                if abs(yaw_command - drone_rpy[2]) > 0.3 and abs(yaw_command - drone_rpy[2]) < (np.pi * 2 - 0.2):
                    speed_command = self._last_action[3]
                    speed_command = max(speed_command, 0.2)
                if abs(yaw_command - drone_rpy[2]) > 0.5 and abs(yaw_command - drone_rpy[2]) < (np.pi * 2 - 0.5):
                    speed_command = self._last_action[3] - brake_rate/4
                    speed_command = max(speed_command, 0.2)
                yaw_command /= np.pi
                if distance_to_goal > 1e-6:
                    direction[2] *= 5.0
                    direction_norm = direction / np.linalg.norm(direction)
                else:
                    direction_norm = np.array([0.0, 0.0, 0.0], dtype=np.float32)

                if drone_altitude < 0.5:
                    direction_norm = np.array([direction_norm[0] * 0.1, direction_norm[1] * 0.1, 1.0], dtype=np.float32)
                if distance_to_goal < 10.0 and self.is_find_P:
                    if self._first_plat_pos is None:
                        self._first_plat_pos = self.landing_platform.copy()
                    elif np.linalg.norm(self._first_plat_pos[0:2] - self.landing_platform[0:2]) > 0.7:
                        self.tracking = True

                if distance_to_goal < 4.0 and self.is_find_P:
                    self._mode = "landing"
                    self.controller.reset()
                    self._landing_platform_position = None

                action = np.concatenate([direction_norm, [speed_command, self._get_yaw_command(yaw_command, drone_rpy)]], dtype=np.float32)
            else:
                action = self._last_action.copy()

            if not is_goal_visible or visible_goal_position is None:
                _spawn_alt = float(self.start_state[2]) if self.start_state is not None else 0.0
                _patience = 15 if _spawn_alt > 15.0 else 10
                self._goal_lost_steps = getattr(self, "_goal_lost_steps", 0) + 1
                if self._goal_lost_steps > _patience:
                    if (self.platform_position is not None
                            and self._goal_return_attempts < 3
                            and self._track_score >= 3):
                        self._last_known_goal_pos = self.platform_position.copy()
                        self._goal_return_mode = True
                        self._goal_return_search_steps = 0
                        self._goal_return_attempts += 1
                        self.extra_search_vectors = None
                        self.search_stage = 0
                        self.search_state_0_rot_count = 0
                    self._mode = "search"
                    self._goal_lost_steps = 0
            else:
                self._goal_lost_steps = 0
        elif self._mode == "landing" and not self.tracking:
            if visible_goal_position is not None:
                goal_position = visible_goal_position.copy()
                goal_position[2] += 0.3

                if self._landing_platform_position is None:
                    if self.move_in_auto_mode:
                        self._landing_platform_position = self.reverse_landing_platform.copy() + np.array([0.0, 0.0, 0.3])
                    else:
                        self._landing_platform_position = self.landing_platform.copy() + np.array([0.0, 0.0, 0.3])
                else:
                    dist_drone_to_anchor = float(np.linalg.norm(drone_position - self._landing_platform_position))
                    dxy = float(np.linalg.norm(goal_position[0:2] - self._landing_platform_position[0:2]))
                    if dist_drone_to_anchor < 1.5 and dxy < 0.5:
                        self._landing_platform_position[0:2] = (
                            0.8 * self._landing_platform_position[0:2] + 0.2 * goal_position[0:2]
                        )

                direction_to_landing_point = self._landing_platform_position - drone_position
                direction_to_current_goal_position = goal_position - drone_position
                distance_to_landing_point = float(np.linalg.norm(direction_to_landing_point))
                horizontal_distance_to_current_goal_position = float(
                    np.linalg.norm(goal_position[0:2] - drone_position[0:2]))

                brake_rate = 0.01
                speed_command = self._last_action[3] - brake_rate
                speed_bound = min(distance_to_landing_point/6.0, 0.5)
                speed_command = max(speed_command, max(0.25, speed_bound))
                speed_command = min(speed_command, self._last_action[3])

                yaw_command = np.arctan2(direction_to_current_goal_position[1],
                                         direction_to_current_goal_position[0]) / np.pi

                if distance_to_landing_point > 0.2:
                    direction_to_landing_point[2] *= 2.0
                    direction_norm = direction_to_landing_point / np.linalg.norm(direction_to_landing_point)
                    if distance_to_landing_point > 0.5 and self.move_in_auto_mode:
                        direction_norm[0:2] += 20.0*self.reverse_d[0:2]
                else:
                    direction_norm = np.array([0.0, 0.0, 0.0], dtype=np.float32)
                    speed_command = 0.0
                if np.linalg.norm(self.reverse_landing_platform[0:2] - self._landing_platform_position[0:2]) > 0.7:
                    self.tracking = True

                if horizontal_distance_to_current_goal_position < 0.6:
                    direction_to_landing_point[2] *= 2.0
                    direction_norm = direction_to_landing_point / np.linalg.norm(direction_to_landing_point)/3.0
                    direction_norm[2] = -1.0
                    speed_command = max(0.3, self._last_action[3] - brake_rate)

                if horizontal_distance_to_current_goal_position < 0.2:
                    direction_to_landing_point[2] *= 2.0
                    direction_norm = np.array([0.0, 0.0, 0.0])
                    direction_norm[2] = -1.0
                    speed_command = max(0.2, self._last_action[3] - brake_rate)

                self._last_landing_hdist = horizontal_distance_to_current_goal_position
                action = np.concatenate([direction_norm, [speed_command, self._get_yaw_command(yaw_command, drone_rpy)]], dtype=np.float32)
            else:
                action = self._last_action.copy()

            if not is_goal_visible or visible_goal_position is None:
                self._landing_patience += 1
                _close_range = (self._last_landing_hdist is not None and self._last_landing_hdist < 0.5)
                _land_patience = 30 if _close_range else 10
                if self._landing_patience > _land_patience:
                    if (self.platform_position is not None
                            and self._goal_return_attempts < 3
                            and self._track_score >= 3):
                        self._last_known_goal_pos = self.platform_position.copy()
                        self._goal_return_mode = True
                        self._goal_return_search_steps = 0
                        self._goal_return_attempts += 1
                        self.extra_search_vectors = None
                        self.search_stage = 0
                        self.search_state_0_rot_count = 0
                    self._landing_platform_position = None
                    self._landing_patience = 0
                    self._mode = "search"
                elif _close_range:
                    action = np.array([0.0, 0.0, -1.0, 0.3, self._last_action[4]], dtype=np.float32)
            else:
                self._landing_patience = 0
        elif self._mode == "landing" and self.tracking:
            if visible_goal_position_cov is not None:
                goal_position = self.reverse_landing_platform.copy() + self.reverse_d*13
                horizontal_distance_to_current_goal_position = float(np.linalg.norm(goal_position[0:2] - drone_position[0:2]))
                if self._landing_platform_position is None:
                    self._landing_platform_position = visible_goal_position_cov.copy() + np.array([0.0, 0.0, 0.3])
                goal_position[2] = self._landing_platform_position[2]
                if horizontal_distance_to_current_goal_position < 1.0:
                    goal_position[2] -= 0.5

                self.controller.set_setpoint(goal_position)
                action = self.controller.update(drone_position, setpoint_v=self.reverse_d*13)

                direction_to_landing_point = goal_position - drone_position
                distance_to_landing_point = float(np.linalg.norm(direction_to_landing_point))
                unit_vect_to_landing_point = direction_to_landing_point / np.linalg.norm(direction_to_landing_point)

                brake_rate = 0.01
                speed_command = 0.3
                yaw_command = np.arctan2(direction_to_landing_point[1],direction_to_landing_point[0]) / np.pi

                action[2] = action[2] * 2.0
                direction_norm = action / np.linalg.norm(action)
                speed_command = min(np.linalg.norm(action), 1.0)
                speed_command = self._last_action[3] + np.sign(speed_command - self._last_action[3])*brake_rate
                if horizontal_distance_to_current_goal_position < 0.6:
                    direction_norm = action / np.linalg.norm(action)/2.0
                    direction_norm[2] = -1.0
                    speed_command = max(0.3, self._last_action[3] - brake_rate)

                self._last_landing_hdist = horizontal_distance_to_current_goal_position
                action = np.concatenate([direction_norm, [speed_command, self._get_yaw_command(yaw_command, drone_rpy)]], dtype=np.float32)
            else:
                action = self._last_action.copy()

            if not is_goal_visible or visible_goal_position is None:
                self._landing_patience += 1
                _close_range = (self._last_landing_hdist is not None and self._last_landing_hdist < 0.5)
                _land_patience = 30 if _close_range else 10
                if self._landing_patience > _land_patience:
                    if (self.platform_position is not None
                            and self._goal_return_attempts < 3
                            and self._track_score >= 3):
                        self._last_known_goal_pos = self.platform_position.copy()
                        self._goal_return_mode = True
                        self._goal_return_search_steps = 0
                        self._goal_return_attempts += 1
                        self.extra_search_vectors = None
                        self.search_stage = 0
                        self.search_state_0_rot_count = 0
                    self._landing_platform_position = None
                    self._landing_patience = 0
                    self._mode = "search"
                elif _close_range:
                    action = np.array([0.0, 0.0, -1.0, 0.3, self._last_action[4]], dtype=np.float32)
            else:
                self._landing_patience = 0
        else:
            action = np.array([0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float32)
        direct_goal_direction = action[0:3]
        if (self._mode == "search" and distance_to_search_area > 3.0) or self._mode == "navigation":
            camera_position, camera_target, _, up_direction, _ = _cam_geom(
                drone_position,
                drone_rpy,
            )

            ctx = _safe_ctx(
                depth_map=depth,
                camera_position=camera_position,
                camera_target=camera_target,
                fov_deg=CAMERA_FOV_DEG,
                current_direction=action[0:3],
                camera_target_is_point=True,
                camera_up=up_direction,
                working_resolution=32,
            )

            waypoint_direction = _pick_ctx(
                ctx,
                safety_margin_m=0.35,
                preferred_clearance_m=10.0,
                max_lookahead_m=15.0,
            )

            waypoint_direction_close = _pick_ctx(
                ctx,
                safety_margin_m=1.1, 
                preferred_clearance_m=2.0,  
                max_lookahead_m=3.3,  
            )
            dir_similarity = 1.0
            if np.linalg.norm(action[0:3]) > 0 and np.linalg.norm(waypoint_direction_close) > 0:
                dir_1 = action[0:3] / np.linalg.norm(action[0:3])
                dir_2 = waypoint_direction_close / np.linalg.norm(waypoint_direction_close)
                dir_similarity = np.dot(dir_1, dir_2)

                if dir_similarity < 0.99:
                    waypoint_direction = waypoint_direction_close

            self._forward = dir_similarity >= 0.99
            action = np.concatenate([waypoint_direction, [action[3], action[4]]]).astype(np.float32)
            action = self.collipe_avoidance(depth, state, action, direct_goal_direction)

        if not self._inside_goal_zone and dist_raw_3d < 10.0:
            self._inside_goal_zone = True
        if self._inside_goal_zone and dist_raw_3d > 12.0:
            _back_vec = np.asarray([state[-3], state[-2], state[-1]], dtype=np.float32)
            _bn = float(np.linalg.norm(_back_vec))
            if _bn > 1e-6:
                _back_dir = _back_vec / _bn
                action = np.concatenate([
                    _back_dir,
                    [min(float(action[3]), 0.5), action[4]],
                ]).astype(np.float32)

        if self._last_action is not None:
            slerp_dir_vector = slerp_dir(
                a=self._last_action[0:3],
                b=action[0:3],
                t=slerp_steps
            )

            action = np.concatenate([slerp_dir_vector, [action[3], action[4]]]).astype(np.float32)

        action = np.clip(action, -3.0, 3.0)

        self._last_action = action
        is_first_order = False
        if (self._mode == "navigation" or self._mode == "search") and not self._forward:
            is_first_order = True
            self.first_order_cnt = 35
        elif self.first_order_cnt > 0:
            self.first_order_cnt -= 1
            is_first_order = True
        else:
            is_first_order = False
        
        final_action = self._getSecondOrderAction(action, state, is_smooth=is_first_order)
        _tilt = max(abs(float(drone_rpy[0])), abs(float(drone_rpy[1])))
        _max_v_err = max(0.2, 2.2 - (2.0 / 0.7) * max(0.0, _tilt - 0.3))
        final_action = self._reference_governor(final_action, drone_velocity, max_v_err=_max_v_err, speed_limit=3.0)
        return final_action

    def _reference_governor(self, action_1x5, drone_velocity_world, max_v_err=2.2, speed_limit=3.0):
        a = np.asarray(action_1x5, dtype=np.float32).reshape(-1).copy()
        new_v = a[0:3] * a[3] * speed_limit
        v_err = new_v - np.asarray(drone_velocity_world, dtype=np.float32)
        v_err_mag = float(np.linalg.norm(v_err))
        if v_err_mag > max_v_err:
            scale = max_v_err / v_err_mag
            new_v_safe = drone_velocity_world + v_err * scale
            new_speed_mag = float(np.linalg.norm(new_v_safe))
            if new_speed_mag > 1e-6:
                a[0:3] = (new_v_safe / new_speed_mag).astype(np.float32)
                a[3] = float(new_speed_mag / speed_limit)
            else:
                a[3] = 0.0
        if np.asarray(action_1x5).ndim == 2:
            return a.reshape(1, 5).astype(np.float32)
        return a.astype(np.float32)


    def collipe_avoidance(self, depth, state, action, gaol_direction):
        depth_input = np.asarray(depth, dtype=np.float32)
        if depth_input.ndim == 2:
            depth_input = depth_input[None, None, :, :]
        elif depth_input.ndim == 3 and depth_input.shape[-1] == 1:
            depth_input = np.transpose(depth_input, (2, 0, 1))[None, ...]
        elif depth_input.ndim != 4:
            raise ValueError(f"expected depth shape (H,W), (H,W,1), or (N,C,H,W), got {depth_input.shape}")

        state_input = np.asarray(state, dtype=np.float32).reshape(-1)
        action_input = np.asarray(action, dtype=np.float32).reshape(-1)
        gaol_direction = np.asarray(gaol_direction, dtype=np.float32).reshape(-1)
        if action_input.shape != (5,):
            raise ValueError(f"expected navigation action shape (5,), got {action_input.shape}")

        model_inputs = {}
        if "depth" in self._navigation_model_inputs:
            model_inputs["depth"] = depth_input
        if "state" in self._navigation_model_inputs:
            model_inputs["state"] = state_input
        if "action" in self._navigation_model_inputs:
            model_inputs["action"] = action_input
        if "goal_direction" in self._navigation_model_inputs:
            model_inputs["goal_direction"] = gaol_direction
        navigation_outputs = self._navigation_model_session.run(None, model_inputs)
        avoid_direction = navigation_outputs[0]
        if len(navigation_outputs) > 1:
            self.is_hatt = bool(np.asarray(navigation_outputs[1]).reshape(-1)[0])
        if len(navigation_outputs) > 2:
            self.is_dense = bool(np.asarray(navigation_outputs[2]).reshape(-1)[0])
        
        return np.asarray(avoid_direction, dtype=np.float32).reshape(-1)

    def reset(self):
        self._mode = "takeoff"
        self._goal_visibility_threshold = 0.5
        self._goal_visible_enter_threshold = 0.55
        self._goal_visible_exit_threshold = 0.35
        self._last_action = np.array([0.0, 0.0, 0.0, 0.0, 0.0])
        self.M = None
        if not hasattr(self, "_m_model"):
            self._m_model = None
        if not hasattr(self, "_m_device"):
            self._m_device = None
        if not hasattr(self, "_m_state_dim"):
            self._m_state_dim = None
        self._landing_platform_position = None
        self._high_flight = False
        self._mountain_flight = False
        self._landing_patience = 0
        self._goal_is_tracked = False
        self.prev_action = np.array([0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float32)
        self.start_state = None
        self.see_P = True
        self.platform_position = None
        self.reverse_landing_platform = None
        self.landing_platform = None
        self.platform_lost_step = 0
        self.p_buffer = 10.0
        self.reverse_d = np.array([0.0, 0.0, 0.0])
        self.move_in_auto_mode = False
        self.reverse_buffer = np.array([[0.0, 0.0, 0.0]])
        self.last_reverse_buffer = np.array([[0.0, 0.0, 0.0]])
        self.is_find_P = False
        self.tracking = False
        self._forward = True
        self._first_plat_pos = None
        if hasattr(self, "_ab_tracker"):
            self._ab_tracker.reset()
        self.extra_search_vectors = None
        self.search_stage = 0
        self.search_state_0_rot_count = 0
        self.d_t_speed = np.array([0.0, 0.0, 0.0])
        self.first_order_cnt = 0
        self._last_known_goal_pos = None
        self._goal_return_mode = False
        self._goal_return_attempts = 0
        self._goal_return_search_steps = 0
        self._last_landing_hdist = None
        self._track_score = 0
        self._track_reject_streak = 0
        self._inside_goal_zone = False
        self.vk = np.array([0.0, 0.0, 0.0])
        self.vkm1 = np.array([0.0, 0.0, 0.0])
        self.is_hatt = True
        self.is_dense = True

    def _get_search_area_position(self, search_area_vector, drone_position):
        search_direction = search_area_vector / np.linalg.norm(search_area_vector)
        if self.extra_search_vectors is None:
            self.extra_search_vectors = [
                np.array([0.0, 0.0, 0.0]),
                search_direction * 10.0,
                rpy_to_rot(0.0, 0.0, 3 * np.pi/4) @ search_direction * 10.0,
                rpy_to_rot(0.0, 0.0, 6 * np.pi/4) @ search_direction * 10.0,
                rpy_to_rot(0.0, 0.0, 1 * np.pi/4) @ search_direction * 10.0,
                rpy_to_rot(0.0, 0.0, 4 * np.pi/4) @ search_direction * 10.0,
                rpy_to_rot(0.0, 0.0, 7 * np.pi/4) @ search_direction * 10.0,
                rpy_to_rot(0.0, 0.0, 2 * np.pi/4) @ search_direction * 10.0,
                rpy_to_rot(0.0, 0.0, 5 * np.pi/4) @ search_direction * 10.0,
            ]
        search_area_position = search_area_vector + drone_position
        search_area_position[:2] += self.extra_search_vectors[self.search_stage][:2]
        return search_area_position
    def _find_platform(self, depth, state):
        pr, tr, pv, pq = self._predict_goal(depth, state, state[:3], state[3:6])
        is_visible = pr > 0.8

        if is_visible and self._ab_tracker.initialized:
            elapsed_steps = max(1, self.platform_lost_step + 1)
            predicted = self._ab_tracker.pos + self._ab_tracker.vel * elapsed_steps * SIM_DT
            innovation = float(np.linalg.norm(tr - predicted))
            max_innovation = 3.0 * elapsed_steps * SIM_DT + 2.0
            if innovation > max_innovation:
                is_visible = False
                pr = 0.0
                self._track_score = max(0, self._track_score - 2)
                self._track_reject_streak += 1
                if self._track_reject_streak >= 5 and self._track_score == 0:
                    self._ab_tracker.reset()
                    self._track_reject_streak = 0
            else:
                self._track_score = min(10, self._track_score + 1)
                self._track_reject_streak = 0
        elif is_visible:
            self._track_score = min(10, self._track_score + 1)
            self._track_reject_streak = 0

        if self.platform_position is None:
            self.platform_position = state[0:3] + state[-3:]
            self.reverse_landing_platform = self.platform_position.copy()
            self.landing_platform = self.platform_position.copy()
        if is_visible:
            self.see_P = True
            self.platform_position = tr
            self.platform_lost_step = 0
            self._ab_tracker.update(tr)
        elif self.see_P:
            self.platform_lost_step += 1
            if self.platform_lost_step > 20:
                self.see_P = False
                self.is_find_P = False
        else:
            self.platform_position = state[0:3] + state[-3:]
        goal_pos = self.platform_position.copy()
        self.reverse_landing_platform = 0.7 * (self.landing_platform + self.reverse_d) + 0.3 * goal_pos
        self.landing_platform = 0.7 * self.landing_platform + 0.3 * goal_pos
        self.detect_reverse_direction(goal_pos, self.reverse_landing_platform)
        dist_to_go = np.linalg.norm(goal_pos - self.landing_platform)
        if self.move_in_auto_mode:
            dist_to_go = np.linalg.norm(goal_pos - self.reverse_d - self.landing_platform)
        self.p_buffer = 0.7 * self.p_buffer + 0.3 * dist_to_go
        if dist_to_go < 0.1 and  self.p_buffer < 0.1 and is_visible:
            self.is_find_P = True
        else:
            self.is_find_P = False
        return pr, tr, pv, pq[:3]
    
    def detect_reverse_direction(self, a, b):
        self.reverse_buffer = np.concatenate([self.reverse_buffer, a.reshape(1,3).copy()])
        self.last_reverse_buffer = np.concatenate([self.last_reverse_buffer, b.reshape(1,3).copy()])
        if len(self.reverse_buffer) > 50:
            self.reverse_buffer = self.reverse_buffer[1:]
        if len(self.last_reverse_buffer) > 10:
            self.last_reverse_buffer = self.last_reverse_buffer[1:]
        if len(self.reverse_buffer) < 15:
            return
        d_vect_reverse = self.reverse_buffer[10:] - self.reverse_buffer[:-10]
        error = 0.0
        for x, v in enumerate(d_vect_reverse[:-1]):
            norm = np.linalg.norm(v) * np.linalg.norm(d_vect_reverse[x+1])
            pro = v @ d_vect_reverse[x+1]
            if norm < 1e-12 or pro < 0:
                continue
            error += pro / norm
            
        d_vect_reverse = self.last_reverse_buffer[1:] - self.last_reverse_buffer[:-1]
        mean_d_reverse = np.mean(d_vect_reverse, axis=0)
        platform_speed = np.linalg.norm(mean_d_reverse)
        if error > 30.0 and platform_speed > 0.012 and platform_speed < 0.05:
            self.move_in_auto_mode = True
            self.reverse_d = mean_d_reverse

    def _get_yaw_command(self, yaw_command_1, drone_rpy):
        drone_yaw = drone_rpy[2]
        drone_yaw_rescaled = drone_yaw/np.pi
        yaw_command_2 = yaw_command_1 + 2 if yaw_command_1 < 0 else yaw_command_1 - 2
        yaw_command = yaw_command_1 if abs(yaw_command_1 - drone_yaw_rescaled) < abs(yaw_command_2 - drone_yaw_rescaled) else yaw_command_2
        diff = yaw_command - drone_yaw_rescaled
        is_safe = abs(drone_rpy[0]) < 0.7 and abs(drone_rpy[1]) < 0.7
        if not is_safe:
            return drone_yaw_rescaled
        if abs(diff) < 0.02:
            return yaw_command_1
        
        if diff > 0.0:
            return self._rot_left(drone_yaw)
        else:
            return self._rot_right(drone_yaw)
        
    def _rot_left(self, drone_yaw):
        max_yaw_change = MAX_YAW_RATE * SIM_DT
        new_drone_yaw_angle = drone_yaw + max_yaw_change - 1e-4
        new_drone_yaw_angle_normalized = new_drone_yaw_angle / np.pi

        if new_drone_yaw_angle_normalized > 1.0:
            new_drone_yaw_angle_normalized = (new_drone_yaw_angle_normalized - 1.0) - 1.0

        if new_drone_yaw_angle_normalized < -1.0:
            new_drone_yaw_angle_normalized = (new_drone_yaw_angle_normalized + 1.0) + 1.0

        return np.clip(new_drone_yaw_angle_normalized, -1.0, 1.0)

    def _rot_right(self, drone_yaw):
        max_yaw_change = MAX_YAW_RATE * SIM_DT
        new_drone_yaw_angle = drone_yaw - max_yaw_change - 1e-4
        new_drone_yaw_angle_normalized = new_drone_yaw_angle / np.pi

        if new_drone_yaw_angle_normalized > 1.0:
            new_drone_yaw_angle_normalized = (new_drone_yaw_angle_normalized - 1.0) - 1.0

        if new_drone_yaw_angle_normalized < -1.0:
            new_drone_yaw_angle_normalized = (new_drone_yaw_angle_normalized + 1.0) + 1.0

        return np.clip(new_drone_yaw_angle_normalized, -1.0, 1.0)

    def _load_model(self, m_model_path: Path):
        m_model_path = Path(m_model_path)
        if not m_model_path.exists():
            raise FileNotFoundError(f"Model not found: {m_model_path}")

        device = torch.device("cpu")
        try:
            model = torch.jit.load(str(m_model_path), map_location=device)
        except Exception as exc:
            raise RuntimeError(
                f"Failed to load TorchScript goal detector from {m_model_path}."
            ) from exc

        model.eval()

        self._m_model = model
        self._m_device = device
        self._m_state_dim = m_STATE_DIM


    def _load_navigation_model(self, nav_model_path: Path):
        nav_model_path = Path(nav_model_path)
        if not nav_model_path.exists():
            raise FileNotFoundError(f"Model not found: {nav_model_path}")

        try:
            sess_opts = ort.SessionOptions()
            sess_opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
            sess_opts.intra_op_num_threads = 2
            session = ort.InferenceSession(
                str(nav_model_path),
                sess_options=sess_opts,
                providers=["CPUExecutionProvider"],
            )
        except Exception as exc:
            raise RuntimeError(
                "Failed to load ONNX navigation model. If the model was exported with external data, "
                f"keep the referenced .onnx.data file next to {nav_model_path}."
            ) from exc

        inputs = {input_info.name: input_info for input_info in session.get_inputs()}
        missing_inputs = sorted({"depth", "action"} - set(inputs))
        if missing_inputs:
            raise KeyError(f"ONNX navigation model missing required inputs: {missing_inputs}")

        outputs = session.get_outputs()
        if len(outputs) < 1:
            raise KeyError("ONNX navigation model expected at least one output")

        self._navigation_model_session = session
        self._navigation_model_inputs = inputs
        self._navigation_model_output_name = outputs[0].name



    def _predict_goal(
        self,
        depth: np.ndarray,
        state: np.ndarray,
        drone_position: np.ndarray,
        drone_rpy: np.ndarray,
    ) -> tuple[float, np.ndarray]:
        depth_input = np.asarray(depth, dtype=np.float32)
        if depth_input.ndim != 3 or depth_input.shape[-1] != 1:
            raise ValueError(f"expected depth shape (H,W,1), got {depth_input.shape}")

        camera_position, camera_target, _, _, _ = _cam_geom(
            drone_position,
            drone_rpy,
        )

        state_input = np.asarray(state, dtype=np.float32).reshape(-1)
        if self._m_state_dim is not None and state_input.shape[0] != self._m_state_dim:
            raise ValueError(
                "Goal detector state shape mismatch: "
                f"expected {self._m_state_dim}, got {state_input.shape[0]}"
            )

        depth_b = depth_input[None, ...]
        cam_pos_b = camera_position[None, :].astype(np.float32, copy=False)
        cam_tgt_b = camera_target[None, :].astype(np.float32, copy=False)
        fov_b = np.asarray([CAMERA_FOV_DEG], dtype=np.float32)
        state_b = state_input[None, :]
        dev = self._m_device
        with torch.inference_mode():
            prediction, self.M = self._m_model(
                torch.from_numpy(depth_b).to(dev),
                torch.from_numpy(state_b).to(dev),
                torch.from_numpy(cam_pos_b).to(dev),
                torch.from_numpy(cam_tgt_b).to(dev),
                torch.from_numpy(fov_b).to(dev),
                self.M,
            )
            prediction = prediction.detach().cpu().numpy()
        prediction = np.asarray(prediction, dtype=np.float32)
        if prediction.shape != (1, 11):
            raise ValueError(f"expected output shape (1,11), got {prediction.shape}")

        visibility_prob = float(prediction[0, 0])
        pred_world = prediction[0, 1:4].astype(np.float32, copy=True)
        pred_world_cov = prediction[0, 4:7].astype(np.float32, copy=True)
        pred_q = prediction[0, 7:11].astype(np.float32, copy=True)
        dist_from_start = np.linalg.norm(pred_world - self.start_state[:3])
        if dist_from_start < 3.5:
            visibility_prob = 0.0
        return visibility_prob, pred_world, pred_world_cov, pred_q
 
class LandingController:    
    def __init__(
        self,
        gains: Gains = None,
        setpoint: Optional[np.ndarray] = None,
        error_deadband: float = 0.01,
    ):
        self.gains = gains or Gains()
        self.setpoint = setpoint if setpoint is not None else np.zeros(3)
        self.error_deadband = error_deadband
        
        
    def update(
        self,
        current_pos: np.ndarray,
        setpoint_v: Optional[np.ndarray] = None,
        feedforward: Optional[np.ndarray] = None,
    ) -> np.ndarray:
        current_pos = np.array(current_pos)
        
        error = self.setpoint - current_pos
        error_magnitude = np.linalg.norm(error)
        if error_magnitude < self.error_deadband:
            error = np.zeros(3)
        
        p_term = self.gains.K * error
                
        ff_term = np.zeros(3)
        if setpoint_v is not None:
            ff_term = self.gains.K * 1.0 * np.array(setpoint_v)
            ff_term[2] = 0.0
        
        if feedforward is not None:
            ff_term += np.array(feedforward)
        
        output = p_term + ff_term
        return output
    
    
    def set_gains(self, K: float):
        """Update PID gains dynamically."""
        self.gains.K = K
    
    def set_setpoint(self, setpoint: np.ndarray):
        """Update target position."""
        self.setpoint = np.array(setpoint)
    
    def reset(self):
        """Reset controller state."""
